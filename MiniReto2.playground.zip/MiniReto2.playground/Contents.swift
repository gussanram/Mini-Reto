//: Playground - noun: a place where people can play

import UIKit

var listado = 0...100

for i in listado{
    if i % 5 == 0{
        print("\(i) ¡bingo!")
    }

    if i % 2 == 0{
        print("\(i) par")
    }else {
        print("\(i) impar")
    }
    
    if i >= 30 && i <= 40{
        print("\(i) ¡viva Swift!")
    }
    

}



